-------------------------------------------------------------------------
--T and G Apps Ltd.
--Created by Jamie Trinder
--www.tandgapps.co.uk

--For use within CoronaSDK.
--Feel free to use this any way you want. I would be even happier if you
--could link to this tutorial from any of your websites! :)
--http://www.tandgapps.co.uk/2012/08/03/tutorial-tower-defense-game/

--The art was sourced from www.vickiwenderlich.com

--CoronaSDK version 2012.868 was used for this tutorial
-------------------------------------------------------------------------


local M = {}

local function new()  

	local mainGroup = display.newGroup()
	local _W = display.contentWidth
	local _H = display.contentHeight

	-------------------------------------------
	-- *** Background and buttons  ***
	-------------------------------------------
	local function startBtnPress(event)
		director.changeScene("gameInfo", "moveFromRight")
		return true
	end
	local bg = display.newImageRect("images/menuBG.jpg",480,320)
	bg.x = _W*0.5; bg.y = _H*0.5;
	bg:addEventListener("tap", startBtnPress)
	mainGroup:insert(bg)


	return mainGroup
end
M.new = new

return M