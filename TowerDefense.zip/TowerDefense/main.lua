-------------------------------------------------------------------------
--T and G Apps Ltd.
--Created by Jamie Trinder
--www.tandgapps.co.uk

--For use within CoronaSDK.
--Feel free to use this any way you want. I would be even happier if you
--could link to this tutorial from any of your websites! :)
--http://www.tandgapps.co.uk/2012/08/03/tutorial-tower-defense-game/

--The art was sourced from www.vickiwenderlich.com

--CoronaSDK version 2012.868 was used for this tutorial
-------------------------------------------------------------------------



--Hide Status bar from the beginning
display.setStatusBar( display.HiddenStatusBar ) 


--Create a global variable for the level we are on.
--Ideally you shouldnt do this but instead save/load
--Which level you are on.
_G.currentLevel = 1


-- Import director class
local localGroup = display.newGroup()
director = require("director")
localGroup:insert(director.directorView)

director:changeScene("menu")	





