

local M = {}

local function new()
	local physics = require ("physics")	--Require the physics library..
	physics.start()
	physics.setGravity( 0, 0 ) --Set gravity to 0 and start the physics.


	-----------------------------------------------
	--*** Set up our variables and group ***
	-----------------------------------------------
	local localGroup = display.newGroup()
	local levelGroup = display.newGroup() --Setup the display groups we want
	local enemyGroup = display.newGroup()
	local weaponGroup = display.newGroup()
	local overlayGroup = display.newGroup()
	localGroup:insert(levelGroup)
	localGroup:insert(enemyGroup)
	localGroup:insert(weaponGroup)
	localGroup:insert(overlayGroup)

	local _W = display.contentWidth --Width and height parameters
	local _H = display.contentHeight 
	local mRound = math.round
	local mRand = math.random
	local mCeil = math.ceil 
	local mAtan2 = math.atan2 
	local mSqrt = math.sqrt 
	local mPi = math.pi

	--Set up the level data arrays...
	local level = require("level"..currentLevel)
	local moveArray = level.moveArray
	local tileArray = level.tileArray 
	local levelRects = {}

	--Other level informaiton
	local spawnedMax = level.spawnedMax
	local enemyHealth = level.enemyHealth 
	local health = level.health
	local money = level.money 

	--Level Control vars..
	local scoreText, moneyText, healthText 
	local gameIsActive = true --If its false nothing will move etc..
	local spawnInt = 0 --iterated in the gameloop to control spawning
	local spawned = 0 --Keeps track of enemy amount
	local score = 0  --The overall score
	
	--Setup tower/timers/transitions arrays...
	local towerArray = {}
	local towerTimers = {}
	local towerTrans = {}

	--Pre-declare a function.
	local changeText
	local clean


	-----------------------------------------------
	--*** Set up our text objects and the level ***
	-----------------------------------------------
	local function startTowers( tower )
		--Now if theres any towers we need to rotate them.
		--also work out if we can shoot
		local function autoNow()
			local i
			for i = 1, enemyGroup.numChildren do
				local enemy = enemyGroup[i]
				if enemy ~= nil and enemy.x ~= nil and enemy.y ~= nil then
					local xPos = towerArray[tower].x
					local yPos = towerArray[tower].y
					local x = enemy.x; local y = enemy.y;

					--Work out angles/distance
					--sqDistance = distance between the two sqaured.
					--dist is the sqaure root of sqDistance
					--distTime is speed. speed = distance/time
					local angleBetween = mCeil(mAtan2( (y - yPos), (x - xPos) ) * 180 / mPi) + 90
					local sqDistance = ((x-xPos)*(x-xPos))+((y-yPos)*(y-yPos)) --a2+b2=c2
					local dist = mSqrt(sqDistance); --Sqaure root it.

					local distTime = dist/0.4
					if distTime < 0 then distTime = distTime -distTime -distTime end
					

					--If the enemy is close we shoot.
					if dist <= 80 and dist >= 0 or dist >= -80 and dist <= 0 then
						--Rotate the tower..
						towerArray[tower].rotation = angleBetween-180

						--Fire the weapon..
						local shot = display.newCircle(0,3,3)
						shot.x = xPos; shot.y = yPos; 
						shot:setFillColor(240,0,0)
						shot.name = "weapon"; shot.rotation = angleBetween+90;
						physics.addBody(shot, { isSensor = true } )
						weaponGroup:insert(shot)

						local function kill () timer.performWithDelay(2, function() if shot ~= nil then display.remove(shot); shot = nil; end; end,1);end
						towerTrans[tower] = transition.to(shot, {time = distTime, x = x, y = y, onComplete = kill})

						--Break out the loop if we have fired.
						break;
					end
				end
			end
		end
		towerTimers[tower] = timer.performWithDelay(1200,autoNow,0)
	end

	local function levelTouched( event )
		if event.phase == "ended" then
			local hitTile = event.target
			local towerID = hitTile.towerID

			--Place a tower if we can...
			if hitTile.towerOn == false and money >= 50 then
				towerArray[towerID] = display.newImageRect("images/tower1.png",42,42)
				towerArray[towerID].x = hitTile.x; towerArray[towerID].y = hitTile.y
				weaponGroup:insert(towerArray[towerID])

				--Start this tower Firing...
				startTowers( towerID ) 

				--Minus 50 from money
				changeText("money", 50)
				hitTile.towerOn = true 
				
			elseif hitTile.towerOn == true then
				--Remove tower and add 40 money..
				hitTile.towerOn = false
				changeText("money", -30)
				display.remove(towerArray[towerID]); towerArray[towerID] = nil
				timer.cancel(towerTimers[towerID]); towerTimers[towerID] = nil
			end
		end
		return true
	end

	local function levelSetup()
		--Create the level based off the array..
		local i
		for i=1, #tileArray do
			local placementAllowed = false
			local groundImage
			local xPos, yPos
			local numMoveArray = #moveArray

			--Sort out placeable areas etc...
			if tileArray[i] == 0 then 
				groundImage = "images/grass.png" 
				placementAllowed = true
			elseif tileArray[i] == 1 then
				groundImage = "images/floor.png" 
			elseif tileArray[i] == 2 then 
				groundImage = "images/water_01.png" 
			else
				local j
				for j=1, numMoveArray do
					if moveArray[j][2] == i then
						groundImage = moveArray[j][3];
					end
				end
			end

			--Now create the level rectangle...
			levelRects[i] = display.newImageRect(groundImage,40,40)
			if i <= 12 then xPos = 20+(40*(i-1)); yPos = 20
			elseif i <= 24 then xPos = 20+(40*(i-13)); yPos = 60
			elseif i <= 36 then xPos = 20+(40*(i-25)); yPos = 100
			elseif i <= 48 then xPos = 20+(40*(i-37)); yPos = 140
			elseif i <= 60 then xPos = 20+(40*(i-49)); yPos = 180
			elseif i <= 72 then xPos = 20+(40*(i-61)); yPos = 220
			elseif i <= 84 then xPos = 20+(40*(i-73)); yPos = 260
			else xPos = 20+(40*(i-85)); yPos = 300
			end
			levelRects[i].x = xPos; levelRects[i].y = yPos
			levelGroup:insert(levelRects[i])

			--If its the ep (end point) add a physics object to it.
			if tileArray[i] == "ep" then
				levelRects[i].name = "ep"; 
				physics.addBody(levelRects[i], { isSensor = true } )
			end

			--If placement is alowed we create a touch listner for it.
			if placementAllowed == true then 
				levelRects[i].towerOn = false
				levelRects[i].towerID = i
				levelRects[i]:addEventListener("touch", levelTouched)
			end
		end

		--Text items for score etc..
		scoreText	= display.newText("Score: "..score, 0,0, "Helvetica", 15)
		scoreText:setReferencePoint(display.CenterLeftReferencePoint)
		scoreText.x = 10; scoreText.y = 10; overlayGroup:insert(scoreText)

		moneyText = display.newText("Money: "..money, 0,0, "Helvetica", 15)
		moneyText:setReferencePoint(display.CenterReferencePoint)
		moneyText.x = _W*0.48; moneyText.y = 10; overlayGroup:insert(moneyText)

		healthText = display.newText("Health: "..health, 0,0, "Helvetica", 15)
		healthText:setReferencePoint(display.CenterLeftReferencePoint)
		healthText.x = _W*0.81; healthText.y = 10; overlayGroup:insert(healthText)
	end
	levelSetup()
		

	-----------------------------------------------
	--*** Gameover/Win function  ***
	-----------------------------------------------
	--GameOver function.. Gets called when you run out of life!
	local function gameOver()
		gameIsActive = false --Stop the loops from running

		local k,v
		for k,v in pairs(towerTimers) do
			timer.cancel(towerTimers[k])
			towerTimers[k] = nil
		end
		for k,v in pairs(towerTrans) do
			transition.cancel(towerTrans[k])
			towerTrans[k] = nil
		end

		local function restartGame( event ) --Reset and restart everything...
			if event.phase == "ended" then
				director:changeScene("gameInfo")
			end
			return true
		end
		--Show game over text and restart text.
		local gameOverText = display.newText("Ohuh! You died!", 0,0, "Helvetica", 18)
		gameOverText.x = _W*0.5; gameOverText.y = _H*0.35; overlayGroup:insert(gameOverText)

		local gameOverScore = display.newText("With a score of "..score, 0,0, "Helvetica", 18)
		gameOverScore.x = _W*0.5; gameOverScore.y = gameOverText.y + 30; overlayGroup:insert(gameOverScore)

		local tryAgainText = display.newText("Click me to try again!", 0,0, "Helvetica", 18)
		tryAgainText.x = _W*0.5; tryAgainText.y = gameOverScore.y + 50; overlayGroup:insert(tryAgainText)
		tryAgainText:addEventListener("touch", restartGame)
	end

	--TO ADD MORE LEVELS CHANGE THE VARIABLE IN HERE.
	local function levelComplete()
		local function restartGame( event )
			if event.phase == "ended" then
				--Limited it here to 3 so that it wont crash.. 
				--Make more levels and remove this limiter!
				if currentLevel < 3 then
					currentLevel = currentLevel + 1
				end
				clean()
				director:changeScene("gameInfo")
			end
			return true
		end
		--Show game over text and restart text.
		local winText = display.newText("Well done you did level "..currentLevel.."!", 0,0, "Helvetica", 18)
		winText.x = _W*0.5; winText.y = _H*0.35; overlayGroup:insert(winText)

		local winScore = display.newText("With a score of "..score, 0,0, "Helvetica", 18)
		winScore.x = _W*0.5; winScore.y = winText.y + 30; overlayGroup:insert(winScore)

		local nextText = display.newText("Click me to go to the next level!!", 0,0, "Helvetica", 18)
		nextText.x = _W*0.5; nextText.y = winScore.y + 50; overlayGroup:insert(nextText)
		nextText:addEventListener("touch", restartGame)
	end


	--------------------------------------------------------------------------
	--*** Create the main level functions... The most improtant part!  ***
	--------------------------------------------------------------------------
	--Enemy spawn function called from gameLoop...
	local function spawnEnemy()
		local enemy = display.newImageRect("images/enemy1_2.png",40,40)
		enemy.x = levelRects[moveArray[1][2]].x-40;
		enemy.y = levelRects[moveArray[1][2]].y;
		enemy.name = "enemy"; enemy.health = enemyHealth
		enemy.movPoint = "p1" --Used in the gameloop
		physics.addBody(enemy, { isSensor = true } )

		enemy.healthBar1 = display.newRect(0,0,20,3)
		enemy.healthBar1.x = enemy.x; enemy.healthBar1.y = enemy.y -12; 
		enemy.healthBar1:setFillColor(0,255,0)
		
		overlayGroup:insert(enemy.healthBar1)
		enemyGroup:insert(enemy)
	end

	--Function for changing text...
	function changeText( type, amount )
		if type == "health" then 
			health = health - 10; healthText.text = "Health: "..health
			healthText:setReferencePoint(display.CenterLeftReferencePoint)
			healthText.x = _W*0.81;
			if health <= 0 then gameOver() end
		elseif type == "score" then
			score = score + 10
			scoreText.text = "Score: "..score; 
			scoreText:setReferencePoint(display.CenterLeftReferencePoint)
			scoreText.x = 10;
		elseif type == "money" then
			money = money - amount
			moneyText.text = "Money: "..money; 
			moneyText:setReferencePoint(display.CenterReferencePoint)
			moneyText.x = _W*0.48;
		end
	end

	--Called from the gameloop to get direction etc..
	local function gameLoopEnemyCheck( movPoint )
		local transDirecX, transDirecY, rect, nextPoint, rotate

		local function getDirect( moveArray )
			local direc = moveArray
			if direc == "right" then transDirecX = 1; transDirecY = 0; rotate = 0
			elseif direc == "left" then transDirecX = -1; transDirecY = 0; rotate = -180
			elseif direc == "up" then transDirecX = 0; transDirecY = -1; rotate = -90
			elseif direc == "down" then transDirecX = 0; transDirecY = 1; rotate = 90; end
		end

		local i
		for i=1, #moveArray-1 do
			if movPoint == "p"..i then 
				rect = levelRects[moveArray[i+1][2]] 
				getDirect(moveArray[i][1])
				nextPoint = "p"..i+1
			elseif movPoint == "ep" then 
				rect = levelRects[moveArray[i+1][2]] 
				getDirect(moveArray[i][1])
				nextPoint = "ep"
			end
		end

		return transDirecX, transDirecY, rect, nextPoint, rotate
	end

	--Gameloop moves the enemies each frame. Also spawns enemies
	local endCheckAmount = 0
	local function gameLoop(event)
		if gameIsActive == true then
			--Increase the int until it spawns an enemy..
			spawnInt = spawnInt + 1
			if spawnInt == 40 and spawned ~= spawnedMax then 
				spawnEnemy()
				spawnInt = 0
				spawned = spawned + 1

				if spawned == spawnedMax then
					print("GAME SHOULD BE ENDING SOON")
				end
			end	

			--Move enemies along the path..
			--Need to check each point each enemy has made it to.
			local i
			local enemyActive = false
			for i = enemyGroup.numChildren,1,-1 do
				local enemy = enemyGroup[i]
				if enemy ~= nil and enemy.x ~= nil then

					local transDirecX, transDirecY, rect, nextPoint, rotate = gameLoopEnemyCheck(enemy.movPoint)
					enemy:translate( transDirecX, transDirecY)
					enemy.healthBar1:translate( transDirecX, transDirecY)
					enemy.rotation = rotate

					if rect.x == mRound(enemy.x) and rect.y == mRound(enemy.y) then 
						enemy.movPoint = nextPoint 
					end
					enemyActive = true
					endCheckAmount = 0
				end
			end	

			--Using endCheckAmount and enemyActive
			--to finish the game.. checks each frame.
			if enemyActive == false then
				endCheckAmount = endCheckAmount + 1
				if endCheckAmount == 100 then
					print("Amount has maxed, ending the game")
					local timer = timer.performWithDelay(250, levelComplete, 1) 
				end
			end
		end
	end

	--Control collisions and health from here.
	local function onCollision(event)
		if event.phase == "began" and gameIsActive == true then
			--Destory the enemy if it is hit...
			if event.object1 ~= nil and event.object1.name == "enemy" and event.object2.name == "ep" or event.object1 ~= nil and event.object1.name == "ep" and event.object2.name == "enemy" then
				if event.object1.name == "enemy" then 
					display.remove(event.object1.healthBar1)
					event.object1.healthBar1 = nil
					display.remove(event.object1)
					event.object1 = nil
				else 
					display.remove(event.object2.healthBar1)
					event.object2.healthBar1 = nil
					display.remove(event.object2)
					event.object2 = nil
				end

				--Increase the score if we kill and enemy..
				changeText("health")
			end

			--Destory the enemy if it is hit...
			if event.object1 ~= nil and event.object1.name == "enemy" and event.object2.name == "weapon" or event.object1 ~= nil and event.object1.name == "weapon" and event.object2.name == "enemy" then
				if event.object1.name == "enemy" then 
					event.object1.health = event.object1.health-20

					if event.object1.health <= 0 then
						display.remove(event.object1.healthBar1)
						event.object1.healthBar1 = nil
						display.remove(event.object1)
						event.object1 = nil
						changeText("money", -10)
					else
						local healthScale = event.object1.health/enemyHealth
						event.object1.healthBar1.xScale = healthScale
					end
				else 
					event.object2.health = event.object2.health-20
					
					if event.object2.health <= 0 then
						display.remove(event.object2.healthBar1)
						event.object2.healthBar1 = nil
						display.remove(event.object2)
						event.object2 = nil
						changeText("money", -10)
					else
						local healthScale = event.object2.health/enemyHealth
						event.object2.healthBar1.xScale = healthScale
					end
				end

				--Increase the score if we kill and enemy..
				changeText("score")
			end
		end	
	end


	---------------------------------------------------------
	--*** Listeners for touch/collision and a gameloop ***
	---------------------------------------------------------
	Runtime:addEventListener( "enterFrame", gameLoop )
	Runtime:addEventListener( "collision", onCollision )


	function clean()
		Runtime:removeEventListener( "enterFrame", gameLoop )
		Runtime:removeEventListener( "collision", onCollision )

		--Clean timers and transitions..
		--We use "pairs" as there will be gaps
		--in those arrays. Iterating over them
		--normally wouldnt remove them.
		local k,v
		for k,v in pairs(towerTimers) do
			timer.cancel(towerTimers[k])
			towerTimers[k] = nil
		end
		for k,v in pairs(towerTrans) do
			transition.cancel(towerTrans[k])
			towerTrans[k] = nil
		end
	end
	M.clean = clean

	return localGroup
end
M.new = new

return M
