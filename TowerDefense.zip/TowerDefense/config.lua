-- config.lua

application =
{
        content =
        {
                width = 320,
                height = 480,
                scale = "letterbox",
				fps = 30,
				
				imageSuffix =
				{
					["@2x"] = 2,
				},
        },
}
